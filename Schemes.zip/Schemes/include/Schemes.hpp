#ifndef SCHEMES_H
#define SCHEMES_H

#include <iostream>
#include <random>
#include <Eigen/Dense>
#include <ctime>
#include <chrono>
#include <omp.h>


                /************************************************************
                *                                                           *
                *          @brief   Simulation schemes                      *
                *          @author  BOUDCHICHI Oussama                      *
                *                                                           *
                * **********************************************************/ 


class Schemes{

    private:
        // dim : d×1
        Eigen::VectorXd x_0;
        double T;
        // 𝞂(t, X_t) d×d
         Eigen::MatrixXd (*diffusion)(const double&, const Eigen::VectorXd&);

        // 𝝻(t, X_t) d×1
         Eigen::VectorXd (*drift)(const double&, const Eigen::VectorXd&);
        
        Eigen::MatrixXd simulateGaussian(const int& d, const int& N, int seed) const {
            
            Eigen::MatrixXd Z(d, N);
            std::mt19937 G(seed);
            std::normal_distribution <double> Norm(0., 1.);

            for(int i = 0; i < d; i++) {
                for(int j = 0; j < N; j++) Z(i, j) = Norm(G);}

            return Z; 
        }

        // Centered FD approximation of 𝞂'(x), i.e. (𝞂(x + 𝞊) - 𝞂(x - 𝞊)) / 2𝞊
        double derivDiff(const Eigen::VectorXd& x, const double& eps = 1e-6) const {
            Eigen::VectorXd epsi(1); epsi << eps;

            double out = (1. / (2. * eps)) * (diffusion(0., x + epsi)(0) - diffusion(0., x - epsi)(0));
            return out;
        }
    
    public:

        Schemes() {}
        Schemes(const Eigen::VectorXd& x_0_, const double& T_,
                Eigen::MatrixXd (*diffusion_)(const double&, const Eigen::VectorXd&),
                Eigen::VectorXd (*drift_)(const double&, const Eigen::VectorXd&)):
                x_0(x_0_), T(T_),  diffusion(diffusion_), drift(drift_) {}

        virtual ~Schemes() {}

        Eigen::VectorXd generateTraj1d(const int& N, const std::string& type, 
                                       const double& eps = 1e-6,
                                       const bool& verbose = false) const;
        Eigen::MatrixXd generateTrajxd(const int& N, const bool& verbose = false) const;  
};

#endif