#include <iostream>
#include <random>
#include <vector>
#include <algorithm>
#include <gnuplot-iostream.h>
#include <Eigen/Dense>
#include <chrono>
#include <omp.h>
#include "Schemes.hpp"

// % Draw a trajectory of a BM : (B_t) s.t t ∈ [0, T], for N time steps.
std::vector<std::pair<double, double>> draw_B(const int& N, const double& T) {

    std::mt19937 G(time(NULL));
    std::normal_distribution <double> Norm(0., 1.);

    std::vector<std::pair<double, double>> B(N + 1);
    B[0] = std::make_pair(0., 0.);

    double dt = T / (double) N;

    for(int i = 1; i <= N; i++) {
        B[i].first = i * dt;
        B[i].second = B[i - 1].second +  std::sqrt(dt) * Norm(G);
    }
    return B;
}
// std::vector<double> getSecond(const std::vector<std::pair<double, double>>& In) {

//     std::vector<double> out(In.size());
//     //std::transform(In.begin(), In.end(), out.begin(), [&](std::pair<double, double>& x) {return x.second;});
//     for(int i = 0; i < In.size(); i++) out[i] = In[i].second;
//     return out;
// }
// % Draw a trajectory of a GBM : (S_t) s.t t ∈ [0, T], for N time steps.
std::vector<double> draw_GBM(const int& N, const double& T,
                                                const double& sigma,
                                                const double& mu,
                                                const double& S_0) {

    std::vector<std::pair<double, double>> B = draw_B(N, T);
    std::vector<double> GBM(N + 1);

    std::transform(B.begin(), B.end(), GBM.begin(), [&](std::pair<double, double>& x) {
       return S_0 * std::exp((mu - 0.5 * sigma * sigma) * x.first + (sigma * x.second));
    });

    return GBM;                                 
    }



Eigen::VectorXd absErr(const Eigen::VectorXd& X_1, const std::vector<double>& X_2) {
            assert(X_1.size() == X_2.size());
            Eigen::VectorXd out(X_1.size());
    
            for(int i = 0; i < X_1.size(); i++) out(i) = std::abs(X_1(i) - X_2[i]);
            return out;

}

// % Compute errors for both schemes(in the black & Scholes framework).
//columns : 
//|time steps | strong_convergence_err_EM | strong_convergence_err_Mil | weak_convergence_err_EM | weak_convergence_err_Mil|
// % using Multi-threading:
#define NUM_THREADS 8
void computeErrors(Eigen::MatrixXd& errors, const int& MC_sample,
                   const double& T, const double& mu, const double& S_0,
                   const double& sigma,
                   std::vector<double>& times,
                   std::vector<double> timeSteps,
                   Eigen::MatrixXd (*diffusion)(const double&, const Eigen::VectorXd&),
                   Eigen::VectorXd (*drift)(const double&, const Eigen::VectorXd&) ) {
    
    
    Eigen::VectorXd x0(1); x0 << S_0;
    double totalTime = 0.;
    //omp_set_num_threads(NUM_THREADS);
    // % Loop over time steps :
    for(int i = 0; i < timeSteps.size(); i++) {
        auto t0 = std::chrono::system_clock::now();
        
        
        errors(i, 0) = timeSteps[i];
        int N = int(T / timeSteps[i]);
        
        Eigen::VectorXd errEm(N + 1), errMil(N + 1), errEmSum(N + 1), errMilSum(N + 1);
        errEm.setZero(); errMil.setZero(); errEmSum.setZero(); errMilSum.setZero();        
        std::vector<double> ySum(N + 1, 0.);
        
    
        // % Monte-Carlo starts here:
        int j;
        #pragma omp parallel for private(j) shared(errEm, errMil, errEmSum, errMilSum)
        for(int j = 0; j < MC_sample; j++) {
            // % Exact solution
            //std::vector<std::pair<double, double>> 
            std::vector<double> GBM = draw_GBM(N, T, sigma, mu, S_0);
            
            Schemes sch(x0, T, diffusion, drift);
            Eigen::VectorXd outEm, outMil;
            outEm = sch.generateTraj1d(N, "EM");
            outMil = sch.generateTraj1d(N, "Mil");

            //#pragma omp critical
            errEm += absErr(outEm, GBM);
            errMil += absErr(outMil, GBM);

            // % ySum += GBM;
            std::transform(ySum.begin(), ySum.end(), GBM.begin(), ySum.begin(), std::plus<double>());
            errEmSum += outEm; 
            errMilSum += outMil;
        
        }
        
        // % Monte-Carlo finishes here.

        // % strong errors:
        errors(i, 1) = (errEm /(double) MC_sample).maxCoeff();
        errors(i, 2) = (errMil /(double) MC_sample).maxCoeff();

        // % weak errors:
        errors(i, 3) = (absErr(errEmSum, ySum) / (double) MC_sample).maxCoeff();
        errors(i, 4) = (absErr(errMilSum, ySum) / (double) MC_sample).maxCoeff();

        auto t1 = std::chrono::system_clock::now();
        std::chrono::duration<double> diff = t1 - t0;
        
        std::cout << "Matrix of errors N×5" << std::endl;
        std::cout << "Iter : " << i << " Esplaped time : " << diff.count() << " .s" <<  std::endl;
        totalTime += diff.count();
        times.push_back(diff.count());


                   }
     // % Finished.              
    std::cout <<  "Total esplaped time : " << totalTime << " .s" <<  std::endl;
                   }
                   
// % Utils:
// % Common 

Eigen::VectorXd myLog(const Eigen::VectorXd& X) {
    Eigen::VectorXd Y(X.size());
    for(int i = 0; i < X.size(); i++) Y(i) = std::log(X(i));
    return Y;
}

double getSlopeLog(const Eigen::VectorXd& X, const Eigen::VectorXd& Y) {

    Eigen::MatrixXd A(X.size(), 2);
    A.col(0) = Eigen::VectorXd::Ones(X.size()); 
    A.col(1) = myLog(X);
    double x = (((A.transpose() * A).inverse()) * (A.transpose()) * myLog(Y))(1);
    return x;
}


// %% Set-up
void config(gnuplotio::Gnuplot& gp, 
            const std::string& xlabel,
            const std::string& ylabel,
            const std::string& title) {

    // % Graphic settings
    gp << "set style line 1 linecolor rgb '#00008B' linetype 1 dt 2  linewidth 2\n";
    gp << "set style line 2 lw 2 lc rgb '#8B0000' ps 1 pt 6 pi 1\n";
    gp << "set style line 3 linecolor rgb 'black' linetype 1 dt 3  linewidth 2\n";
    gp << "set style line 4 linecolor rgb '#199710' linetype 1 dt 2  linewidth 2\n";
    gp << "set grid\n";
    gp << "set xlabel '" + xlabel + "'\n";
    gp << "set ylabel '" + ylabel + "'\n";
    gp << "set title '" + title + "'\n";
}

// %% Saving figures
void save_fig(gnuplotio::Gnuplot& gp, const std::string& id) {
    std::string fig_dir = "./figures/";
    fig_dir += id;

    gp << "set terminal pdf\n";
    gp << "set output '" + fig_dir +  "'\n";
    gp << "replot\n";
    gp << "unset output\n";
    gp << "unset terminal" << std::endl;
    std::cout << id << " has been successfully saved" << std::endl;
}

