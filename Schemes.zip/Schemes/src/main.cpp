#include <iostream>
#include <random>
#include <ctime>
#include <fstream>
#include <gnuplot-iostream.h>
#include "../include/Schemes.hpp"
#include "../include/Utils.hpp"
#include <functional>

using namespace std;

// % Driver Code
// % Code begins here

// % Change these functions with your desired coeffs
// % Diffusion
Eigen::MatrixXd diffusion1D(const double& t, const Eigen::VectorXd& x) {
    
    Eigen::MatrixXd M(1, 1); 
    M << 2. * x(0); //,0.,
         //0., .2 * x(1);
    return M;
}
// % Drift
Eigen::VectorXd drift1D(const double& t, const Eigen::VectorXd& x) {
    
    Eigen::VectorXd X(1); X <<  x(0); //, .05 * x(1);
    return X;
}



int main() {
    
    std::string fig_dir = "./figures/";
    int N = 1000; double T = 1.;
    Gnuplot gp;
    

    // % Just uncomment the desired chunck of code.

    /*generate a 2dim traj using E-M

    Eigen::VectorXd x_0(2); x_0 << 100., 100.;
    Schemes sch(x_0, T, &diffusion2D, &drift2D);
    auto t0 = std::chrono::system_clock::now();
    Eigen::MatrixXd out = sch.generateTrajxd(N);
    //cout << out << endl;
    auto t1 = std::chrono::system_clock::now();
    std::chrono::duration<double> diff = t1 - t0;
    std::cout << "Esplaped time : " << diff.count() << " .s" << std::endl;

    
    vector <pair<double, double> > plot1;
    for(int i = 0; i < out.cols(); i++) {
        plot1.push_back(make_pair(out(0, i) , out(1, i)));
    }

    config(gp, "X_t^1", "X_t^2", "Simulated diffusion using E-M scheme");
    gp << "set object circle at first " + std::to_string(out(0, 0)) + "," + std::to_string(out(1, 0)) +  " radius char 1. fillstyle empty border lc rgb 'black' lw 2\n";
    gp << "set object circle at first " + std::to_string(out(0, N)) + "," + std::to_string(out(1, N)) +  " radius char 1. fillstyle empty border lc rgb 'red' lw 1\n";
    gp << "plot" << gp.file1d(plot1) << " w l ls 1 dt 1 title '(X_t^1, X_t^2)'" << endl;
    std::string id = "fig1.pdf";
    save_fig(gp, id);
    ***********************/


    /*
    Eigen::VectorXd x_0(1); x_0 << 1.;

    Schemes sch(x_0, T, &diffusion1D, &drift1D);
    Eigen::VectorXd outMil = sch.generateTraj1d(N, "Mil");
    //Eigen::VectorXd outEM = sch.generateTraj1d(N, "EM");
    //vector<double> GBM = draw_GBM(N, T, .2, .05, x_0(0));
    
    
    double dt = T / N;

    vector <pair<double, double> > plot1, plot2, plot3;
    for(int i = 0; i < N; i++) {
        plot1.push_back(make_pair(i * dt, outMil(i)));
        // plot2.push_back(make_pair(i * dt, outEM(i)));
        // plot3.push_back(make_pair(i * dt, GBM[i]));
        
    }
    config(gp, "t", "X_t", "Cox-Ingersoll-Ross process using Milstein scheme");
    // gp << "set size 1.5, 1.5\n";
    // gp << "set multiplot layout 1, 2\n";
    // % 1st plot

    gp << "plot" << gp.file1d(plot1) << " w l ls 1 dt 1 title 'X_t" << endl;
    //<< gp.file1d(plot3) << " w l ls 3 title 'GBM'\n"; //<< endl; 

    // gp << "plot" << gp.file1d(plot2) << " w l ls 2 title 'Euler-Maruyama'," 
    // << gp.file1d(plot3) << " w l ls 3 title 'GBM'" << endl;

    std::string id = "fig3.pdf";
    save_fig(gp, id);
    *************************/
   


    // % Errors approximation
    double sigma = 2.,  mu = 1., X_0 = 1.;
    int MC_sample = 1000000;
    vector<double> timeSteps, times;

    for(int i = 0; i < 5; i++) timeSteps.push_back( pow(2, double(i - 10)) );
    
    Eigen::MatrixXd errors(timeSteps.size(), 5);
    computeErrors(errors, MC_sample, T, mu, X_0, sigma, times,timeSteps, &diffusion1D, &drift1D);

    // % Export results
    ofstream d("data.dat");
    d << "pas temporel\tduree\tECForteEM\tECForteMIL\tECFaibleEM\tECFaibleMil" << endl;
    for(int i = 0; i < errors.rows(); i++)
    {

        d << errors(i, 0) << "\t" <<  times[i] << "\t" << errors(i, 1) << "\t"
        << errors(i, 2) << "\t" << errors(i, 3) << "\t" << errors(i, 4) << endl;
    }
    d.close();
    // % Finished
    

    // % Print convergence rates : 
    for(int i = 1; i < errors.cols(); i++) 
        cout <<  getSlopeLog(errors.col(0), errors.col(i)) << endl;   // % 

   

    vector <pair<double, double> > plot1, plot2, plot3, plot4;
    for(int i = 0; i < errors.rows(); i++) {
        plot1.push_back(make_pair(errors(i, 0), errors(i, 1) ));
        plot2.push_back(make_pair(errors(i, 0), errors(i, 2) ));
        plot3.push_back(make_pair(errors(i, 0), errors(i, 3) ));
        plot4.push_back(make_pair(errors(i, 0), errors(i, 4) ));
        
     }
    
    // % Plot results
    config(gp, "\\delta t", "Errors", "Weak and strong convergence errors");
    gp << "set logscale x 10\n";
    gp << "set logscale y 10\n";

    // % 1st plot
     gp << "plot" << gp.file1d(plot1) << " w l ls 2 title 'Strong Error EM'," 
    << gp.file1d(plot2) <<  " w l ls 1 title 'Strong Error Mil'," 
    << gp.file1d(plot3) <<  " w l ls 3 title 'Weak Error EM',"
    << gp.file1d(plot4) <<  " w l ls 4 title 'Weak Error Mil'" << endl;

    // % Saving figures
    std::string id = "err.pdf";
    save_fig(gp, id);

    cout << "Finished ....." << endl;
    // % Code ends here.
    return 0;
}