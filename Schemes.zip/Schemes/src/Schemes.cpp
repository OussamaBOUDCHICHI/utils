#include "../include/Schemes.hpp"




Eigen::VectorXd Schemes::generateTraj1d(const int& N, 
                                        const std::string& type,
                                        const double& eps, 
                                        const bool& verbose) const {

    assert((type == "EM") || (type == "Mil"));
    Eigen::VectorXd trajs(N + 1);
    
    
    
    trajs(0) = x_0(0);
    double dt = T / (double) N;

    Eigen::VectorXd Z = sqrt(dt) * this -> simulateGaussian(N, 1, time(NULL));
    
    for(int i = 1; i <= N; i++) {
        
         Eigen::VectorXd X(1); X << trajs(i - 1);
         Eigen::VectorXd sigma = diffusion((i - 1) * dt, X), mu = drift((i - 1) * dt, X);

         trajs(i) = X(0) + mu(0) * dt + Z(i - 1) * sigma(0);

        if (type == "Mil") {
            double sigPrime = this -> derivDiff(X, eps);
            trajs(i) += 0.5 * sigma(0) * sigPrime * (Z(i - 1) * Z(i - 1) - dt);
        }
    
    }
    
    
    if(verbose == true) std::cout << "Matrix of trajectories N×1" << std::endl;

    return trajs;

}

Eigen::MatrixXd Schemes::generateTrajxd(const int& N, const bool& verbose) const {
    Eigen::MatrixXd trajs(x_0.size(), N + 1);
    
    trajs.col(0) = x_0;
    double dt = T / (double) N;

    Eigen::MatrixXd Z = sqrt(dt) * this -> simulateGaussian(x_0.size(), N, time(NULL));
    Eigen::VectorXd X;
    for(int i = 1; i <= N; i++) {
         X = trajs.col(i - 1);
         trajs.col(i) = X;
         trajs.col(i) += (dt * drift((i - 1) * dt, X)) + (diffusion((i - 1) * dt, X) * Z.col(i - 1));
}
    
    
    if(verbose == true) std::cout << "Matrix of trajectories d×N" << std::endl;
    return trajs;
}